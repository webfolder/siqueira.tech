#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

static int hello_init_module(void)
{
  printk(KERN_ALERT "Salut, Mundi! Oopss... Hello World!\n");
  return 0;
}

static void hello_exit_module(void)
{
  printk(KERN_ALERT "It is time... good bye!\n");
}

module_init(hello_init_module);
module_exit(hello_exit_module);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rodrigo Siqueira");
MODULE_DESCRIPTION("Hey, this a simple module toy :)");
